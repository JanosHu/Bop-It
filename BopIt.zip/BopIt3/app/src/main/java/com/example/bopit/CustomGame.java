package com.example.bopit;
import static com.example.bopit.BuildLevel.CUSTOM_GAME_COMMAND_LIST;
import static com.example.bopit.MainActivity.poppingWordsOn;
import static com.example.bopit.RecordVoice.customOrderAudios;
import static com.example.bopit.RecordVoice.hasChanged;
import static com.example.bopit.RecordVoice.paths;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.app.Dialog;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import java.io.IOException;
import java.util.Random;

public class CustomGame extends AppCompatActivity {

    MediaPlayer[] commandAudios;

    OrderType[] orderArray;

    int score;
    int orderCounter;//counts current order for order array
    boolean hasFinishedGame;//in order to make game stop receiving actions once it has finished
    public static boolean hasOrderedCustom;
    public static boolean hasWonCustom;// if correctly did every order
    public static boolean isCustomGame;
    public static OrderType orderTypeCustom;
    public boolean isFirst;//in order to make orders sound once
    String[] fadingPraisesArray;
    int praiseArrayCounter;


    Intent flipIntent;
    Intent sliceIntent;
    SwipeListnerCustom swipeListener;


    TextView tvTimer;
    TextView tvScore;
    static TextView tvOrderCustom;
    ConstraintLayout swipeLayout;//the place where swipes are registered
    private TextView fadingTextView1;//for praises
    private TextView fadingTextView2;
    private TextView tvRandomPraise;
    ImageButton bopItButtonCustom;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom_game);

        orderArray=convertToOrderTypesFromInt(getIntent().getIntArrayExtra(CUSTOM_GAME_COMMAND_LIST));//converts the int commands to order types
        commandAudios=customOrderAudios;

        orderCounter=0;
        score=0;
        isCustomGame=true;
        isFirst = true;


        tvScore=findViewById(R.id.tvScoreCustom);
        tvTimer=findViewById(R.id.tvTimerCustom);
        tvOrderCustom=findViewById(R.id.tvOrderCustom);
        fadingTextView1 = findViewById(R.id.tvPoppingWords1Custom);
        fadingTextView2 = findViewById(R.id.tvPoppingWords2Custom);
        swipeLayout = findViewById(R.id.SwipeLayoutCustom);
        bopItButtonCustom=findViewById(R.id.bopItButtonCustom);


        flipIntent = new Intent(this, FlipService.class);
        sliceIntent = new Intent(this, SliceService.class);
        startService(flipIntent);
        startService(sliceIntent);
        swipeListener = new SwipeListnerCustom(swipeLayout);


        fadingPraisesArray = new String[4];
        fadingPraisesArray[0] = "Good Job!";
        fadingPraisesArray[1] = "Nice!";
        fadingPraisesArray[2] = "You Rock!";
        fadingPraisesArray[3] = "Well Done!";
        praiseArrayCounter = -1;


        bopItButtonCustom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                hasOrderedCustom = true;
                orderTypeCustom = OrderType.PRESS;
                tvOrderCustom.setText("Pressed");
            }
        });

        int num=0;
        new CountDownTimer(5000, 1000) {
            public void onTick(long millisUntilFinished) {


                if (!hasFinishedGame) {//as long as game hasn't finished continue to run
                    tvTimer.setText("seconds remaining: " + millisUntilFinished / 1000);

                    if (isFirst)//so audio wont repeat itself
                    {
                        switch (orderArray[orderCounter]) {//order audio handler
                            case PRESS:
                                if(hasChanged[0]==true)
                                {
                                    customOrderAudios[0].reset();
                                    try {
                                        customOrderAudios[0].setDataSource(paths[0]);
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                    try {
                                        customOrderAudios[0].prepare();
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                }

                                customOrderAudios[0].start();
                                break;


                            case FLIP:
                                if(hasChanged[1]==true)
                                {
                                    customOrderAudios[1].reset();
                                    try {
                                        customOrderAudios[1].setDataSource(paths[1]);
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                    try {
                                        customOrderAudios[1].prepare();
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                }

                                customOrderAudios[1].start();
                                break;


                            case SWIPEUP:
                                if(hasChanged[2]==true)
                                {
                                    customOrderAudios[2].reset();
                                    try {
                                        customOrderAudios[2].setDataSource(paths[2]);
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                    try {
                                        customOrderAudios[2].prepare();
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                }

                                customOrderAudios[2].start();
                                break;


                            case SWIPERIGHT:
                                if(hasChanged[3]==true)
                                {
                                    customOrderAudios[3].reset();
                                    try {
                                        customOrderAudios[3].setDataSource(paths[3]);
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                    try {
                                        customOrderAudios[3].prepare();
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                }

                                customOrderAudios[3].start();
                                break;


                            case SWIPEDOWN:
                                if(hasChanged[4]==true)
                                {
                                    customOrderAudios[4].reset();
                                    try {
                                        customOrderAudios[4].setDataSource(paths[4]);
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                    try {
                                        customOrderAudios[4].prepare();
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                }

                                customOrderAudios[4].start();
                                break;


                            case SWIPELEFT:
                                if(hasChanged[5]==true)
                                {
                                    customOrderAudios[5].reset();
                                    try {
                                        customOrderAudios[5].setDataSource(paths[5]);
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                    try {
                                        customOrderAudios[5].prepare();
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                }

                                customOrderAudios[5].start();
                                break;


                            case SLICE:
                                if(hasChanged[6]==true)
                                {
                                    customOrderAudios[6].reset();
                                    try {
                                        customOrderAudios[6].setDataSource(paths[6]);
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                    try {
                                        customOrderAudios[6].prepare();
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                    }
                                }

                                customOrderAudios[6].start();
                                break;
                            default:
                                break;
                        }
                        isFirst = false;
                    }


                    if (hasOrderedCustom) {
                        if (orderArray[orderCounter] == orderTypeCustom)//if order that has been received is equal to the required
                        {
                            if (poppingWordsOn)//if player chose to have fading/popping words on through settings on main page
                            {
                                chooseRandomPraiseText();//have one of two TextViews display a praise
                            }

                            orderCounter++;
                            score++;
                            tvScore.setText("Score: " + score);
                            if (orderCounter == orderArray.length )//if is last order
                            {
                                hasWonCustom = true;
                                hasFinishedGame = true;
                                onFinish();
                            }

                            if (!hasWonCustom)//if didn't win yet
                            {
                                isFirst = true;//is first time for playing vocal order
                                hasOrderedCustom = false;//hasn't ordered yet
                                start();
                            }
                        } else {//if order that has been received isn't equal to required order-> end game
                            hasFinishedGame = true;
                            onFinish();
                        }
                    }
                }
            }

            public void onFinish() {

                gameOver();
                if (hasWonCustom) {
                    tvTimer.setText("Won!");
                } else {
                    tvTimer.setText("Failed!");
                }
                cancel();
            }
        }.start();

        if (hasFinishedGame) {
            stopServices();
        }



    }
    public void stopServices() {
        stopService(sliceIntent);
        stopService(flipIntent);
    }

    public void gameOver() {
        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.dialog_game_over);
        dialog.getWindow().setBackgroundDrawableResource(R.drawable.rounddialog);
        dialog.setCancelable(false);

        final TextView tvWonOrLost;
        final Button btnHome;
        final Button btnPlayAgain;
        final TextView tvScoreGameOver;


        tvWonOrLost = dialog.findViewById(R.id.tvWonOrLost);
        btnHome = dialog.findViewById(R.id.btnHome);
        btnPlayAgain = dialog.findViewById(R.id.btnPlayAgain);
        tvScoreGameOver = dialog.findViewById(R.id.tvScoreGameOver);

        btnHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //after game over go back home
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);

            }
        });
        btnPlayAgain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //after game over play again
                Intent intent = new Intent(getApplicationContext(), CustomGame.class);
                intent.putExtra(CUSTOM_GAME_COMMAND_LIST, convertToIntFromOrderType(orderArray));//so when playing again it will play the same game mode
                hasOrderedCustom=false;//so it wont fail you immediately
                hasWonCustom=false;//so it wont tell you you won when you lost
                startActivity(intent);
                finish();//so cant move back
            }
        });


            if (hasWonCustom) {
                tvWonOrLost.setText("You Won!");
            } else {
                tvWonOrLost.setText("You Lost!");
            }
            tvScoreGameOver.setText("Your score was " + score);



        dialog.show();
    }



    public void chooseRandomPraiseText() {
        Random rnd = new Random();
        int temp = rnd.nextInt(2);
        if (temp == 0) {
            tvRandomPraise = fadingTextView1;
        } else {
            tvRandomPraise = fadingTextView2;
        }
        if (praiseArrayCounter + 1 == fadingPraisesArray.length) {
            praiseArrayCounter = 0;
        } else {
            praiseArrayCounter++;
        }
        tvRandomPraise.setText(fadingPraisesArray[praiseArrayCounter]);

        Runnable endRunnable = new Runnable() {
            @Override
            public void run() {
                tvRandomPraise.setText("");
                tvRandomPraise.animate().alpha(1).setDuration(0).setStartDelay(0);//returns the word's alpha (fade level) back to normal
                tvRandomPraise.animate().scaleX(1);//scales word back to normal
                tvRandomPraise.animate().scaleY(1);//scales word back to normal
            }
        };

        tvRandomPraise.animate().alpha(1).setDuration(500).setStartDelay(0);//fades the word in
        tvRandomPraise.animate().scaleX(2);//scales word x
        tvRandomPraise.animate().scaleY(2);//scales word y
        tvRandomPraise.animate().alpha(0).setDuration(500).setStartDelay(500).withEndAction(endRunnable);//fades the word out and calls endRunnable once finished
    }

    private OrderType[] convertToOrderTypesFromInt(int[] orderTypesInt) {
        OrderType[] orderTypes=new OrderType[orderTypesInt.length];
        for (int i=0;i<orderTypesInt.length;i++)
        {
            orderTypes[i]=(OrderType.fromInteger(orderTypesInt[i]));
        }
        return orderTypes;
    }

    private int[] convertToIntFromOrderType(OrderType[] orderTypes) {
        int[] orderTypesInt=new int[orderTypes.length];
        for (int i=0;i<orderTypesInt.length;i++)
        {
            orderTypesInt[i]=orderTypes[i].ordinal();
        }
        return orderTypesInt;
    }

    private  class SwipeListnerCustom implements View.OnTouchListener {

        GestureDetector gestureDetector;

        SwipeListnerCustom(View view)//constructor
        {
            int threshold = 100;
            int velocityThreshold = 100;

            GestureDetector.SimpleOnGestureListener listener =
                    new GestureDetector.SimpleOnGestureListener() {
                        @Override
                        public boolean onDown(MotionEvent e) {
                            return true;
                        }

                        @Override
                        public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
                            float xDiff = e2.getX() - e1.getX();
                            float yDiff = e2.getY() - e1.getY();
                            try {
                                if (Math.abs(xDiff) > Math.abs(yDiff)) {//x greater than y
                                    if (Math.abs(xDiff) > threshold && Math.abs(velocityX) > velocityThreshold) {
                                        if (xDiff > 0) {
                                            //swiped right


                                            orderTypeCustom = OrderType.SWIPERIGHT;
                                            tvOrderCustom.setText("Swiped Right");

                                        } else {
                                            //swiped left


                                            orderTypeCustom = OrderType.SWIPELEFT;
                                            tvOrderCustom.setText("Swiped Left");
                                        }
                                        hasOrderedCustom = true;


                                        return true;
                                    }
                                } else {//y greater than x
                                    if (Math.abs(yDiff) > threshold && Math.abs(velocityY) > velocityThreshold) {
                                        if (yDiff > 0) {
                                            //swiped down

                                            orderTypeCustom = OrderType.SWIPEDOWN;
                                            tvOrderCustom.setText("Swiped Down");

                                        } else {
                                            //swiped up

                                            orderTypeCustom = OrderType.SWIPEUP;
                                            tvOrderCustom.setText("Swiped Up");
                                        }
                                        hasOrderedCustom = true;


                                        return true;
                                    }
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            return false;
                        }
                    };
            gestureDetector = new GestureDetector(listener);
            view.setOnTouchListener(this);
        }

        @Override
        public boolean onTouch(View view, MotionEvent motionEvent) {
            return gestureDetector.onTouchEvent(motionEvent);
        }
    }
}