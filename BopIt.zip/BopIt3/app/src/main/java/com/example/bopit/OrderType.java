package com.example.bopit;


public enum OrderType {
    PRESS,
    FLIP,
    SWIPEUP,
    SWIPERIGHT,
    SWIPEDOWN,
    SWIPELEFT,
    SLICE;


    public static OrderType fromInteger(int x) {
        switch (x) {
            case 0:
                return PRESS;
            case 1:
                return FLIP;
            case 2:
                return SWIPEUP;
            case 3:
                return SWIPERIGHT;
            case 4:
                return SWIPEDOWN;
            case 5:
                return SWIPELEFT;
            case 6:
                return SLICE;
        }
        return null;
    }


}