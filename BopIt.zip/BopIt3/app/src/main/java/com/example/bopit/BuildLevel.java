package com.example.bopit;

import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.menu.MenuBuilder;
import androidx.appcompat.view.menu.MenuPopupHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;


public class BuildLevel extends AppCompatActivity implements AddCommandAdapter.OnCommandClickListener{

    public static final String CUSTOM_GAME_COMMAND_LIST="CUSTOM_GAME_COMMAND_LIST";

    RecyclerView recyclerViewCommandList;
    ShowCommandAdapter showCommandAdapter;


    Button btnAddNewCommand;
    Button btnBack;
    Button btnNext;
    public static TextView tvCommandCount;
    public static int commandCount;
    Dialog addCommandDialog;


    ArrayList<OrderType> orderTypes;


    RecyclerView recyclerViewAddCommand;
    int[] commandImages = {R.drawable.press_icon,R.drawable.flip_icon,R.drawable.swipe_up_icon,
            R.drawable.swipe_right_icon,R.drawable.swipe_down_icon,R.drawable.swipe_left_icon,R.drawable.slice_icon};
    String[] commandName = {"Press","Flip","Swipe up","Swipe right","Swipe down","Swipe left","Slice"};



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_build_level);


        addCommandDialog=new Dialog(this);

        commandCount=1;
        tvCommandCount=findViewById(R.id.tvCommandCount);
        btnAddNewCommand=findViewById(R.id.btnAddNewCommand);
        btnBack=findViewById(R.id.btnBuildBack);
        btnNext=findViewById(R.id.btnBuildNext);
        recyclerViewCommandList=findViewById(R.id.recyclerView);

        orderTypes=new ArrayList<OrderType>();
        orderTypes.add(OrderType.PRESS);

        showCommandAdapter= new ShowCommandAdapter(orderTypes,commandImages,this);
        recyclerViewCommandList.setAdapter(showCommandAdapter);
        LinearLayoutManager layoutManager
                = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);

        recyclerViewCommandList.setLayoutManager(layoutManager);




        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(commandCount==0)//if no command is in the list
                {
                    Toast.makeText(BuildLevel.this, "You need at least one command to continue", Toast.LENGTH_SHORT).show();
                }
                else{
                    Intent intent= new Intent(BuildLevel.this,RecordVoice.class);
                    int[] orderTypesInt= convertOrdersToInt(orderTypes);
                    intent.putExtra(CUSTOM_GAME_COMMAND_LIST,orderTypesInt);//to pass the command list to the next activity;
                    startActivity(intent);
                    finish();//need to remove -> only for debugging purposes
                }
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(BuildLevel.this,MainActivity.class);
                startActivity(intent);
                finish();
            }
        });


        btnAddNewCommand.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayCommandDialog();
            }
        });

    }

    private int[] convertOrdersToInt(ArrayList<OrderType> orderTypes) {
        int[] temp= new int[orderTypes.size()];
        for (int i=0;i<orderTypes.size();i++)
        {
            temp[i]=orderTypes.get(i).ordinal();
        }
        return temp;

    }


    private void displayCommandDialog() {
        addCommandDialog.setContentView(R.layout.dialog_add_command);
        addCommandDialog.getWindow().setBackgroundDrawableResource(R.drawable.rounddialog);

        recyclerViewAddCommand=addCommandDialog.findViewById(R.id.recyclerViewAddCommand);

        AddCommandAdapter addCommandAdapter= new AddCommandAdapter(addCommandDialog.getContext(),commandImages,commandName,this);
        recyclerViewAddCommand.setAdapter(addCommandAdapter);
        recyclerViewAddCommand.setLayoutManager(new LinearLayoutManager(this));

        addCommandDialog.show();
    }


    @Override
    public void OnCommandClickListener(int position) {
        Log.e("TAG", "OnCommandClickListener: clicked."+position);
        addCommandDialog.dismiss();
        showCommandAdapter.addCommand(OrderType.fromInteger(position));
        recyclerViewCommandList.setAdapter(showCommandAdapter);
        commandCount++;
        tvCommandCount.setText("Amount of commands: "+commandCount);
    }
}