package com.example.bopit;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class Register extends AppCompatActivity {

    public static final String KEY_NICKNAME="KEY_NICKNAME";
    public static final String KEY_EMAIL="EMAIL";
    public static final String KEY_BEGINNER_NORMAL_HIGH_SCORE="KEY_BEGINNER_NORMAL_HIGH_SCORE";
    public static final String KEY_ADVANCED_NORMAL_HIGH_SCORE ="KEY_ADVANCED_NORMAL_HIGH_SCORE";
    public static final String KEY_BEGINNER_ENDLESS_HIGH_SCORE="KEY_BEGINNER_ENDLESS_HIGH_SCORE";
    public static final String KEY_ADVANCED_ENDLESS_HIGH_SCORE="KEY_ADVANCED_ENDLESS_HIGH_SCORE";
    public static final String KEY_USER_REVIEWS_AMOUNT="KEY_USER_REVIEWS_AMOUNT";
    public static final String KEY_USER_HAS_REVIEWS="KEY_USER_HAS_REVIEWS";



    EditText inputEmail,inputPassword, inputConfirmPassword,inputNickName;
    Button btnRegister;
    Map<String,Object> user;


    FirebaseAuth auth;
    FirebaseFirestore db;
    String userId;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        inputEmail=findViewById(R.id.inputEmail);
        inputNickName=findViewById(R.id.inputNickName);
        inputPassword=findViewById(R.id.inputPassword);
        inputConfirmPassword=findViewById(R.id.inputConfirmPassword);
        btnRegister=findViewById(R.id.btnRegister);


        auth = FirebaseAuth.getInstance();
        db =FirebaseFirestore.getInstance();

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String txt_nickName=inputNickName.getText().toString();
                String txt_email = inputEmail.getText().toString();
                String txt_password = inputPassword.getText().toString();
                String txt_confirmPassword = inputConfirmPassword.getText().toString();
                if(TextUtils.isEmpty(txt_email))
                {
                    inputEmail.setError("Email can't be empty");
                }
                else {
                    if (TextUtils.isEmpty(txt_password)) {
                        inputPassword.setError("Password can't be empty");
                    } else {
                        if (txt_password.length() < 6) {
                            inputPassword.setError("Password is too short");
                        }
                        else {
                            if(!txt_password.equals(txt_confirmPassword))
                            {
                                inputConfirmPassword.setError("Passwords do not match");
                            }
                            else{
                                registerUser(txt_nickName,txt_email,txt_password);
                            }
                        }
                    }
                }
            }
        });
    }
    private void registerUser(String nickName, String email, String password)
    {
        auth.createUserWithEmailAndPassword(email,password).addOnCompleteListener( new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful())
                {
                    Toast.makeText(Register.this, "User registered", Toast.LENGTH_SHORT).show();
                    userId=auth.getCurrentUser().getUid();
                    DocumentReference documentReference = db.collection("Users").document(userId);
                    user = new HashMap<>();
                    user.put(KEY_NICKNAME,nickName);
                    user.put(KEY_EMAIL,email);
                    user.put(KEY_USER_HAS_REVIEWS,false);
                    user.put(KEY_BEGINNER_NORMAL_HIGH_SCORE,0);
                    user.put(KEY_ADVANCED_NORMAL_HIGH_SCORE ,0);
                    user.put(KEY_BEGINNER_ENDLESS_HIGH_SCORE,0);
                    user.put(KEY_ADVANCED_ENDLESS_HIGH_SCORE,0);

                    documentReference.set(user).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if(task.isSuccessful())
                            {
                                Toast.makeText(Register.this, "User profile created for user: "+userId, Toast.LENGTH_SHORT).show();
                            }
                            else
                            {
                                Toast.makeText(Register.this, "Failed to create user", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });

                    Map<String,Object> newUserReviews=new HashMap<>();

                    DocumentReference documentReferenceTemp = db.collection("Reviews").document(userId);
                    newUserReviews.put(KEY_USER_REVIEWS_AMOUNT,0);
                    newUserReviews.put(KEY_NICKNAME,nickName);

                    documentReferenceTemp.set(newUserReviews);




                    Intent intent=new Intent(Register.this,GameActivity.class);
                    intent.putExtra(MainActivity.EXTRA_IS_TUTORIAL, true);
                    startActivity(intent);
                    finish();
                }
                else{
                    Toast.makeText(Register.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}