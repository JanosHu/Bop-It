package com.example.bopit;

import static com.example.bopit.BuildLevel.CUSTOM_GAME_COMMAND_LIST;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.Dialog;
import android.content.ContextWrapper;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class RecordVoice extends AppCompatActivity implements View.OnClickListener {


    final int REQUEST_AUDIO_PERMISSiON_CODE = 1000;
    public static MediaPlayer[] customOrderAudios;
    MediaRecorder mediaRecorder;
    boolean isRecording = false;
    boolean isPlaying = false;
    int seconds = 0;
    static String[] paths;
    int dummySecond = 0;
    int playableSeconds;
    ExecutorService executorService = Executors.newSingleThreadExecutor();
    Handler handler;
    TextView tvTimerDisplay;
    int tempI = 0;


    Dialog wantToRecordDialog;
    ArrayList<OrderType> orderTypes;
    int[] orderTypesInt;


    static boolean[] hasChanged;
    Button[] btnsRecord;
    Button[] btnsListen;
    Button btnBack;
    Button btnStart;


    DisplayCommandsAdapter displayCommandsAdapter;
    RecyclerView recyclerViewCommandList;
    int[] commandImages = {R.drawable.press_icon,R.drawable.flip_icon,R.drawable.swipe_up_icon,
            R.drawable.swipe_right_icon,R.drawable.swipe_down_icon,R.drawable.swipe_left_icon,R.drawable.slice_icon};



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record_voice);

        wantToRecordDialog = new Dialog(this);
        Intent intent = getIntent();
        orderTypesInt = intent.getIntArrayExtra(CUSTOM_GAME_COMMAND_LIST);


        wantToRecordDialog.setContentView(R.layout.dialog_want_to_record);
        wantToRecordDialog.getWindow().setBackgroundDrawableResource(R.drawable.rounddialog);
        wantToRecordDialog.setCancelable(false);


        recyclerViewCommandList=findViewById(R.id.recyclerView);
        btnBack = findViewById(R.id.btnBuildBack2);
        btnStart = findViewById(R.id.btnBuildStart);
        final Button btnYes = wantToRecordDialog.findViewById(R.id.btnYes);
        final Button btnNo = wantToRecordDialog.findViewById(R.id.btnNo);

        displayCommandsAdapter= new DisplayCommandsAdapter(convertToOrderTypesFromInt(orderTypesInt),commandImages,this);
        recyclerViewCommandList.setAdapter(displayCommandsAdapter);
        LinearLayoutManager layoutManager
                = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);

        recyclerViewCommandList.setLayoutManager(layoutManager);


        hasChanged=new boolean[7];
        hasChanged[0] = false;
        hasChanged[1] = false;
        hasChanged[2] = false;
        hasChanged[3] = false;
        hasChanged[4] = false;
        hasChanged[5] = false;
        hasChanged[6] = false;

        paths = new String[7];
        paths[0] = null;
        paths[1] = null;
        paths[2] = null;
        paths[3] = null;
        paths[4] = null;
        paths[5] = null;
        paths[6] = null;

        tvTimerDisplay = findViewById(R.id.tvTimeDisplay);
        btnsRecord = new Button[7];
        btnsRecord[0] = findViewById(R.id.btnRecordNewPRESS);
        btnsRecord[1] = findViewById(R.id.btnRecordNewFLIP);
        btnsRecord[2] = findViewById(R.id.btnRecordNewSWIPEUP);
        btnsRecord[3] = findViewById(R.id.btnRecordNewSWIPERIGHT);
        btnsRecord[4] = findViewById(R.id.btnRecordNewSWIPEDOWN);
        btnsRecord[5] = findViewById(R.id.btnRecordNewSWIPELEFT);
        btnsRecord[6] = findViewById(R.id.btnRecordNewSLICE);

        btnsListen = new Button[7];
        btnsListen[0] = findViewById(R.id.btnListenToCommandPRESS);
        btnsListen[1] = findViewById(R.id.btnListenToCommandFLIP);
        btnsListen[2] = findViewById(R.id.btnListenToCommandSWIPEUP);
        btnsListen[3] = findViewById(R.id.btnListenToCommandSWIPERIGHT);
        btnsListen[4] = findViewById(R.id.btnListenToCommandSWIPEDOWN);
        btnsListen[5] = findViewById(R.id.btnListenToCommandSWIPELEFT);
        btnsListen[6] = findViewById(R.id.btnListenToCommandSLICE);

        btnsRecord[0].setOnClickListener(this);
        btnsRecord[1].setOnClickListener(this);
        btnsRecord[2].setOnClickListener(this);
        btnsRecord[3].setOnClickListener(this);
        btnsRecord[4].setOnClickListener(this);
        btnsRecord[5].setOnClickListener(this);
        btnsRecord[6].setOnClickListener(this);

        btnsListen[0].setOnClickListener(this);
        btnsListen[1].setOnClickListener(this);
        btnsListen[2].setOnClickListener(this);
        btnsListen[3].setOnClickListener(this);
        btnsListen[4].setOnClickListener(this);
        btnsListen[5].setOnClickListener(this);
        btnsListen[6].setOnClickListener(this);


        btnYes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (ContextCompat.checkSelfPermission(RecordVoice.this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(RecordVoice.this, "Permission granted", Toast.LENGTH_SHORT).show();
                    wantToRecordDialog.dismiss();
                } else {
                    requestRecordPermission();
                }
            }
        });


        btnNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RecordVoice.this, CustomGame.class);
                intent.putExtra(CUSTOM_GAME_COMMAND_LIST, orderTypesInt);//to pass the command list to the next activity;
                startActivity(intent);
                finish();
            }
        });

        wantToRecordDialog.show();

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RecordVoice.this, BuildLevel.class);
                intent.putExtra(CUSTOM_GAME_COMMAND_LIST, orderTypesInt);//to pass the command list to the next activity;
                startActivity(intent);
                finish();
            }
        });
        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RecordVoice.this, CustomGame.class);
                intent.putExtra(CUSTOM_GAME_COMMAND_LIST, orderTypesInt);//to pass the command list to the next activity;
                startActivity(intent);
                finish();
            }
        });

        customOrderAudios = new MediaPlayer[7];
        customOrderAudios = new MediaPlayer[7];
        customOrderAudios[0] = MediaPlayer.create(this, R.raw.press);
        customOrderAudios[1] = MediaPlayer.create(this, R.raw.flip);
        customOrderAudios[2] = MediaPlayer.create(this, R.raw.swipeup);
        customOrderAudios[3] = MediaPlayer.create(this, R.raw.swiperight);
        customOrderAudios[4] = MediaPlayer.create(this, R.raw.swipedown);
        customOrderAudios[5] = MediaPlayer.create(this, R.raw.swipeleft);
        customOrderAudios[6] = MediaPlayer.create(this, R.raw.slice);
    }

    private OrderType[] convertToOrderTypesFromInt(int[] orderTypesInt) {
        OrderType[] orderTypes=new OrderType[orderTypesInt.length];
        for (int i=0;i<orderTypesInt.length;i++)
        {
            orderTypes[i]=(OrderType.fromInteger(orderTypesInt[i]));
        }
        return orderTypes;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_AUDIO_PERMISSiON_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission granted", Toast.LENGTH_SHORT).show();
                wantToRecordDialog.dismiss();
            } else {
                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
            }

        }

    }

    private void requestRecordPermission() {

        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.RECORD_AUDIO)) {
            new AlertDialog.Builder(this)
                    .setTitle("Permission needed")
                    .setMessage("This permission is needed in order to record audio")
                    .setPositiveButton("ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            ActivityCompat.requestPermissions(RecordVoice.this, new String[]{
                                    Manifest.permission.RECORD_AUDIO
                            }, REQUEST_AUDIO_PERMISSiON_CODE);
                        }
                    })
                    .setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    })
                    .create().show();
        } else {
            ActivityCompat.requestPermissions(this, new String[]{
                    Manifest.permission.RECORD_AUDIO
            }, REQUEST_AUDIO_PERMISSiON_CODE);
        }


    }


    int type;

    @Override
    public void onClick(View view) {//for record audio buttons

        boolean isListenBtn = false;

        for (int i = 0; i < btnsListen.length; i++)//to check if the pressed button was a listen or record button
        {
            if (view == btnsListen[i]) {
                isListenBtn = true;
            }
        }


        if (isListenBtn) {


            for (int i = 0; i < btnsListen.length; i++) {

                if (view == btnsListen[i]) {

                    if (!isPlaying) {//if isn't playing sound

                        if (paths[i] != null) {//if there is a file path

                            customOrderAudios[i].reset();//to make MediaPlayer return to idle stage

                            try {
                                customOrderAudios[i].setDataSource(getRecordingFilePath(i));//sets file path to correct orderAudio
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        } else {//if there hasn't been a recording
                            Toast.makeText(getApplicationContext(), "No Recording Present", Toast.LENGTH_SHORT).show();
                            for (int j = 0; j < btnsListen.length; j++)//to return buttons to clickable because they wont reach the end to do so
                            {
                                if (i > j) {
                                    btnsRecord[j].setClickable(true);
                                    btnsRecord[j].getBackground().setTint(Color.parseColor("#F29F9B"));
                                    btnsListen[j].getBackground().setTint(Color.parseColor("#F29F9B"));
                                    btnsListen[j].setClickable(true);
                                }
                            }

                            return;
                        }

                        try {
                            customOrderAudios[i].prepare();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                        customOrderAudios[i].start();

                        isPlaying = true;

                        runTimer(i);

                    }

                }

                btnsListen[i].getBackground().setTint(Color.parseColor("#2C3075"));//make all buttons unClickable
                btnsListen[i].setClickable(false);
                btnsRecord[i].getBackground().setTint(Color.parseColor("#2C3075"));
                btnsRecord[i].setClickable(false);


            }

        } else {

            for (int i = 0; i < btnsListen.length; i++) {
                btnsListen[i].getBackground().setTint(Color.parseColor("#2C3075"));
                btnsListen[i].setClickable(false);
            }

            for (int i = 0; i < btnsRecord.length; i++) {
                if (isRecording) {
                    if (view == btnsRecord[i])//stop recording
                    {
                        hasChanged[i]=true;
                        btnsRecord[i].setText("Record");

                        tempI = i;
                    }
                    btnsRecord[i].setClickable(true);
                    btnsRecord[i].getBackground().setTint(Color.parseColor("#F29F9B"));
                    btnsListen[i].getBackground().setTint(Color.parseColor("#F29F9B"));
                    btnsListen[i].setClickable(true);
                } else {
                    if (view != btnsRecord[i]) {
                        btnsRecord[i].setClickable(false);
                        btnsRecord[i].getBackground().setTint(Color.parseColor("#2C3075"));

                    } else {
                        type = i;
                        btnsRecord[i].setText("Stop");
                        tempI = i;
                    }
                }
            }
            if (!isRecording) {
                isRecording = true;
                executorService.execute(new Runnable() {
                    @Override
                    public void run() {
                        mediaRecorder = new MediaRecorder();
                        mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
                        mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
                        mediaRecorder.setOutputFile(getRecordingFilePath(type));
                        paths[tempI] = getRecordingFilePath(type);
                        mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);

                        try {
                            mediaRecorder.prepare();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                        mediaRecorder.start();
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                playableSeconds = 0;
                                seconds = 0;
                                dummySecond = 0;
                                runTimer(tempI);
                            }
                        });
                    }
                });
            } else {
                executorService.execute(new Runnable() {
                    @Override
                    public void run() {
                        mediaRecorder.stop();
                        mediaRecorder.release();
                        mediaRecorder = null;
                        playableSeconds = seconds;
                        dummySecond = seconds;
                        seconds = 0;
                        isRecording = false;

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                handler.removeCallbacksAndMessages(null);
                            }
                        });
                    }
                });
            }
        }


    }

    private void runTimer(int i) {
        handler = new Handler();
        handler.post(new Runnable() {
            @Override
            public void run() {
                int minutes = (seconds % 3600) / 60;
                int secs = seconds % 60;
                String time = String.format(Locale.getDefault(), "%02d:%02d", minutes, secs);
                tvTimerDisplay.setText(time);

                if (isRecording || (isPlaying && playableSeconds != -1)) {
                    seconds++;
                    playableSeconds--;

                    if (playableSeconds == -1 && isPlaying) {
                        for (int i = 0; i < btnsListen.length; i++)//to make all buttons clickable after listening
                        {
                            btnsRecord[i].setClickable(true);
                            btnsListen[i].setClickable(true);
                            btnsRecord[i].getBackground().setTint(Color.parseColor("#F29F9B"));
                            btnsListen[i].getBackground().setTint(Color.parseColor("#F29F9B"));

                        }


                        isPlaying = false;
                        customOrderAudios[i].stop();
                        customOrderAudios[i].release();
                        customOrderAudios[i] = null;
                        customOrderAudios[i] = new MediaPlayer();
                        playableSeconds = dummySecond;
                        seconds = 0;
                        handler.removeCallbacksAndMessages(null);
                        return;
                    }

                }
                handler.postDelayed(this, 1000);
            }
        });
    }

    private String getRecordingFilePath(int type) {
        ContextWrapper contextWrapper = new ContextWrapper(getApplicationContext());
        File music = contextWrapper.getExternalFilesDir(Environment.DIRECTORY_MUSIC);
        File file = new File(music, "testFile" + OrderType.fromInteger(type).toString().toLowerCase() + ".mp3");
        return file.getPath();
    }
}