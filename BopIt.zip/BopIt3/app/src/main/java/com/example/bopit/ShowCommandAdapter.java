package com.example.bopit;
import static com.example.bopit.BuildLevel.commandCount;
import static com.example.bopit.BuildLevel.tvCommandCount;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ShowCommandAdapter extends RecyclerView.Adapter<ShowCommandAdapter.MyViewHolder> {

    Context context;
    ArrayList<OrderType> orderTypes;
    int[] images;

    public ShowCommandAdapter(ArrayList<OrderType> orderTypes,int[] images,Context context)
    {
        this.orderTypes=orderTypes;
        this.images=images;
        this.context=context;
    }
    public void addCommand(OrderType orderType)
    {
        orderTypes.add(orderType);
    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.show_command_row,parent,false);
        return new ShowCommandAdapter.MyViewHolder(view).linkAdapter(this);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.tvBuildCommandName.setText(orderTypes.get(position)+"");
        holder.imgViewBuildCommandLogo.setImageResource(images[orderTypes.get(position).ordinal()]);
        holder.tvCommandPlace.setText((position+1)+"");

    }

    @Override
    public int getItemCount() {
        return orderTypes.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{

        TextView tvBuildCommandName;
        TextView tvCommandPlace;
        ImageView imgViewBuildCommandLogo;
        ImageButton imgBtnDeleteCommand;
        ShowCommandAdapter showCommandAdapter;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            tvBuildCommandName= itemView.findViewById(R.id.tvBuildCommandName);
            imgViewBuildCommandLogo= itemView.findViewById(R.id.imgViewBuildCommandLogo);
            imgBtnDeleteCommand=itemView.findViewById(R.id.imbBtnDeleteCommand);
            tvCommandPlace=itemView.findViewById(R.id.tvShowCommandPlace);

            imgBtnDeleteCommand.setOnClickListener(new View.OnClickListener() {//removes command on click
                @Override
                public void onClick(View v) {
                    showCommandAdapter.orderTypes.remove(getAdapterPosition());
                    showCommandAdapter.notifyItemRemoved(getAdapterPosition());
                    commandCount--;
                    tvCommandCount.setText("Amount of commands: "+commandCount);
                    this.notifyAll();
                }
            });
        }
        public MyViewHolder linkAdapter(ShowCommandAdapter showCommandAdapter)
        {
            this.showCommandAdapter=showCommandAdapter;
            return this;
        }

    }

}
