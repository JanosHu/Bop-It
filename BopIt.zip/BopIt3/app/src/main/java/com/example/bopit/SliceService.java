package com.example.bopit;

import static com.example.bopit.CustomGame.isCustomGame;
import static com.example.bopit.GameActivity.dialogCounter;
import static com.example.bopit.GameActivity.hasOrdered;
import static com.example.bopit.GameActivity.isTutorial;
import static com.example.bopit.GameActivity.tvInstructionsStatic;
import static com.example.bopit.GameActivity.tvOrder;
import static com.example.bopit.GameActivity.orderType;

import static com.example.bopit.CustomGame.orderTypeCustom;
import static com.example.bopit.CustomGame.tvOrderCustom;
import static com.example.bopit.CustomGame.hasOrderedCustom;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;
import android.os.IBinder;




public class SliceService extends Service implements SensorEventListener {

    private SensorManager mSensorManager;
    private Sensor mLinearAcceleration;
    private double curDistance;
    private double lastDistance;
    private double distance;
    private boolean isFirst;
    private boolean isFirstTut;
    public static float[] curPos;

    @Override

    public int onStartCommand(Intent intent, int flags, int startId) {

        isFirst = true;
        mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        mLinearAcceleration = mSensorManager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION);
        mSensorManager.registerListener(this, mLinearAcceleration, SensorManager.SENSOR_DELAY_UI, new Handler());
        isFirstTut=true;
        return START_STICKY;
    }



    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        if(isFirst)
        {
            curPos=getCurrentPosLinear(sensorEvent);//get current phone's position in X Y Z
            isFirst=false;

        }

        lastDistance = curDistance;
        curDistance=Math.sqrt(Math.pow(curPos[0]-sensorEvent.values[0],2)+Math.pow(curPos[2]-sensorEvent.values[2],2));
        double delta = curDistance - lastDistance;
        distance = distance * .6f + delta;
        if(distance>30) {

            if (isCustomGame) {
                orderTypeCustom = OrderType.SLICE;
                tvOrderCustom.setText("Sliced");
                hasOrderedCustom = true;
            }
            else {
                if(isTutorial)
                {
                    if(isFirstTut)
                    {
                        dialogCounter++;
                        tvInstructionsStatic.setText("You're so good at this! The last order is swipe.");
                        isFirstTut=false;
                    }
                }
                else{

                    orderType=OrderType.SLICE;
                    hasOrdered = true;
                    tvOrder.setText("Sliced");
                }
            }
        }
    }
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }
    public float[] getCurrentPosLinear(SensorEvent event)
    {
        float[] curPos = new float[3];
        curPos[0] = event.values[0];
        curPos[1] = event.values[1];
        curPos[2] = event.values[2];
        return curPos;
    }
}
