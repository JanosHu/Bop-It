package com.example.bopit;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.SeekBar;
import android.widget.TextView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.List;


public class MainActivity extends AppCompatActivity {


    ConstraintLayout layoutDifficulty;
    ImageButton imgBtnLeaderBoard, imgBtnSettings;
    ImageButton imgBtnDown, imgBtnUp;
    ImageButton imgBtnModeDown, imgBtnModeUp;
    ImageButton imgBtnPlay;
    ImageButton imgBtnMore;
    Dialog settingsDialog;
    Dialog leaderBoardDialog;
    TextView txtViewLevel;
    TextView tvGameMode;

    MediaPlayer toggleSound;

    static boolean poppingWordsOn;
    int levelDiff;
    int gameMode;//1->normal 2->endless 3->multiplayer? 4->build your level
    int gameModeLeaderboard;//1->normal beginner   2->normal advanced   3->endless beginner   4->endless advanced
    public static final String EXTRA_LEVEL_DIFF = "levelDifficulty";
    public static final String EXTRA_POPPING_WORDS_ON = "poppingWordsOn";
    public static final String EXTRA_GAME_MODE = "gameMode";
    public static final String EXTRA_IS_TUTORIAL = "isTutorial";

    FirebaseAuth auth;
    FirebaseFirestore db;

    String[] nickNamesNB; //Normal Beginner
    String[] nickNamesNA; //Normal Advanced
    String[] nickNamesEB; //Endless Beginner
    String[] nickNamesEA; //Endless Advanced

    List<DocumentSnapshot> organizedListBeginnerNormal;
    List<DocumentSnapshot> organizedListAdvancedNormal;
    List<DocumentSnapshot> organizedListBeginnerEndless;
    List<DocumentSnapshot> organizedListAdvancedEndless;
    int[] highScoreBegNorm;
    int[] highScoreAdNorm;
    int[] highScoreBegEnd;
    int[] highScoreAdEnd;
    int curUserPlaceNB;
    int curUserPlaceNA;
    int curUserPlaceEB;
    int curUserPlaceEA;


    ScoreBoardAdapter myAdapter;//for leaderboards
    RecyclerView recyclerView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        db = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();
        if (auth.getCurrentUser() == null)//if user was once sign in keep him signed in, if not send him to log in
        {
            startActivity(new Intent(MainActivity.this, LogIn.class));
            finish();
        }


        curUserPlaceNB = 0;
        curUserPlaceNA = 0;
        curUserPlaceEB = 0;
        curUserPlaceEA = 0;

        settingsDialog = new Dialog(this);
        leaderBoardDialog = new Dialog(this);

        toggleSound = MediaPlayer.create(this, R.raw.toggle_buttons);

        layoutDifficulty = findViewById(R.id.layoutDifficulty);
        imgBtnLeaderBoard = findViewById(R.id.imageLeaderBoard);
        imgBtnSettings = findViewById(R.id.imageSettings);
        txtViewLevel = findViewById(R.id.levelNumberDisplay);
        imgBtnPlay = findViewById(R.id.imgBtnPlay);
        imgBtnDown = findViewById(R.id.imgBtnDown);
        imgBtnUp = findViewById(R.id.imgBtnUp);
        imgBtnModeDown = findViewById(R.id.imgBtnChangeGameModeDown);
        imgBtnModeUp = findViewById(R.id.imgBtnChangeGameModeUp);
        imgBtnMore=findViewById(R.id.imgBtnMore);
        tvGameMode = findViewById(R.id.tvGameModeName);

        gameMode = 1;
        levelDiff = 1;
        poppingWordsOn = true;


        imgBtnMore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PopupMenu popupMenu=new PopupMenu(MainActivity.this,v);
                popupMenu.getMenuInflater().inflate(R.menu.menu,popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {

                        switch (item.getItemId())
                        {
                            case R.id.item1:
                                Intent intent = new Intent(MainActivity.this, LeaveReviewActivity.class);
                                startActivity(intent);
                                finish();
                                return true;


                            case R.id.item2:
                                finishAndRemoveTask();
                                return true;

                            default:
                                return false;
                        }

                    }
                });
                popupMenu.show();
            }
        });

        imgBtnModeDown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleSound.start();

                switch (gameMode) {
                    case 1:
                        tvGameMode.setText("Build Level");
                        gameMode = 4;
                        layoutDifficulty.setVisibility(View.INVISIBLE);
                        break;
                    case 2:
                        tvGameMode.setText("Normal");
                        gameMode--;
                        break;
                    case 3:
                        tvGameMode.setText("Endless");
                        gameMode--;
                        break;
                    case 4:
                        tvGameMode.setText("Multiplayer");
                        layoutDifficulty.setVisibility(View.VISIBLE);
                        gameMode--;
                        break;
                }

            }
        });
        imgBtnModeUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                toggleSound.start();

                switch (gameMode) {
                    case 1:
                        tvGameMode.setText("Endless");
                        gameMode++;
                        break;
                    case 2:
                        tvGameMode.setText("Multiplayer");
                        gameMode++;

                        break;
                    case 3:
                        tvGameMode.setText("Build Level");
                        gameMode++;
                        layoutDifficulty.setVisibility(View.INVISIBLE);
                        break;
                    case 4:
                        tvGameMode.setText("Normal");
                        gameMode = 1;
                        layoutDifficulty.setVisibility(View.VISIBLE);
                        break;
                }
            }
        });

        imgBtnDown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                toggleSound.start();

                if (levelDiff == 1) {
                    levelDiff = 2;
                    txtViewLevel.setText("Advanced");
                } else {
                    levelDiff = 1;
                    txtViewLevel.setText("Beginner");
                }

            }
        });//decreases level difficulty

        imgBtnUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                toggleSound.start();

                if (levelDiff == 2) {
                    levelDiff = 1;
                    txtViewLevel.setText("Beginner");
                } else {
                    levelDiff = 2;
                    txtViewLevel.setText("Advanced");
                }

            }
        });//increases level difficulty

        if(auth.getCurrentUser().getEmail().equals("admin@gmail.com"))//so it wont crash because admin doesn't have any db info
        {
            imgBtnPlay.setEnabled(false);
        }

        imgBtnPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                toggleSound.start();
                moveToGameActivity();
            }
        });//starts the game activity


        imgBtnLeaderBoard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showLeaderBoardDialog();
            }
        });
        imgBtnSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showSettingsDialog(findViewById(R.id.mainLayout));
            }
        }); //opens up settings

    }

    private void showLeaderBoardDialog() {
        db.collection("Users").orderBy("KEY_BEGINNER_NORMAL_HIGH_SCORE", Query.Direction.DESCENDING).get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() { //to get Normal Beginner names and scores
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                List<DocumentSnapshot> snapshotList = queryDocumentSnapshots.getDocuments();
                int cou = 1;
                for (DocumentSnapshot snapshot : snapshotList) {
                    Log.e("MainActivity", "onSuccess: " + snapshot.getData());
                    if (auth.getCurrentUser().getEmail().equals(snapshot.get("EMAIL").toString())) {
                        curUserPlaceNB = cou;
                    }
                    cou++;
                }
                String[] nickNamesTemp = new String[snapshotList.size()];
                int[] scores = new int[snapshotList.size()];
                for (int i = 0; i < snapshotList.size(); i++) {

                        nickNamesTemp[i] = snapshotList.get(i).get("KEY_NICKNAME").toString();
                        scores[i] = Integer.parseInt(snapshotList.get(i).get("KEY_BEGINNER_NORMAL_HIGH_SCORE").toString());


                }
                highScoreBegNorm = scores;
                nickNamesNB = nickNamesTemp;


                myAdapter = new ScoreBoardAdapter(leaderBoardDialog.getContext(), nickNamesNB, highScoreBegNorm, curUserPlaceNB);


                recyclerView = leaderBoardDialog.findViewById(R.id.recyclerViewLeaderBoard);
                recyclerView.setAdapter(myAdapter);
                recyclerView.setLayoutManager(new LinearLayoutManager(leaderBoardDialog.getContext()));
            }
        });
        db.collection("Users").orderBy("KEY_ADVANCED_NORMAL_HIGH_SCORE", Query.Direction.DESCENDING).get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() { //to get Normal Advanced names and scores
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                List<DocumentSnapshot> snapshotList = queryDocumentSnapshots.getDocuments();
                int cou = 1;
                for (DocumentSnapshot snapshot : snapshotList) {
                    Log.e("MainActivity", "onSuccess: " + snapshot.getData());
                    if (auth.getCurrentUser().getEmail().equals(snapshot.get("EMAIL").toString())) {
                        curUserPlaceNA = cou;
                    }
                    cou++;
                }

                String[] nickNamesTemp = new String[snapshotList.size()];
                int[] scores = new int[snapshotList.size()];
                for (int i = 0; i < snapshotList.size(); i++) {


                        nickNamesTemp[i] = snapshotList.get(i).get("KEY_NICKNAME").toString();
                        scores[i] = Integer.parseInt(snapshotList.get(i).get("KEY_ADVANCED_NORMAL_HIGH_SCORE").toString());

                }
                highScoreAdNorm = scores;
                nickNamesNA = nickNamesTemp;

            }
        });
        db.collection("Users").orderBy("KEY_BEGINNER_ENDLESS_HIGH_SCORE", Query.Direction.DESCENDING).get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() { //to get Endless Beginner names and scores
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                List<DocumentSnapshot> snapshotList = queryDocumentSnapshots.getDocuments();
                int cou = 1;
                for (DocumentSnapshot snapshot : snapshotList) {
                    Log.e("MainActivity", "onSuccess: " + snapshot.getData());
                    if (auth.getCurrentUser().getEmail().equals(snapshot.get("EMAIL").toString())) {
                        curUserPlaceEB = cou;
                    }
                    cou++;
                }
                String[] nickNamesTemp = new String[snapshotList.size()];
                int[] scores = new int[snapshotList.size()];
                for (int i = 0; i < snapshotList.size(); i++) {
                        nickNamesTemp[i] = snapshotList.get(i).get("KEY_NICKNAME").toString();
                        scores[i] = Integer.parseInt(snapshotList.get(i).get("KEY_BEGINNER_ENDLESS_HIGH_SCORE").toString());


                }
                highScoreBegEnd = scores;
                nickNamesEB = nickNamesTemp;


            }
        });
        db.collection("Users").orderBy("KEY_ADVANCED_ENDLESS_HIGH_SCORE", Query.Direction.DESCENDING).get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() { //to get Endless Advanced names and scores
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                List<DocumentSnapshot> snapshotList = queryDocumentSnapshots.getDocuments();
                int cou = 1;
                for (DocumentSnapshot snapshot : snapshotList) {
                    Log.e("MainActivity", "onSuccess: " + snapshot.getData());
                    if (auth.getCurrentUser().getEmail().equals(snapshot.get("EMAIL").toString())) {
                        curUserPlaceEA = cou;
                    }
                    cou++;
                }
                String[] nickNamesTemp = new String[snapshotList.size()];
                int[] scores = new int[snapshotList.size()];
                for (int i = 0; i < snapshotList.size(); i++) {
                        nickNamesTemp[i] = snapshotList.get(i).get("KEY_NICKNAME").toString();
                        scores[i] = Integer.parseInt(snapshotList.get(i).get("KEY_ADVANCED_ENDLESS_HIGH_SCORE").toString());

                }
                highScoreAdEnd = scores;
                nickNamesEA = nickNamesTemp;
            }
        });


        leaderBoardDialog.setContentView(R.layout.dialog_leaderboard);
        leaderBoardDialog.getWindow().setBackgroundDrawableResource(R.drawable.rounddialog);

        final ImageButton btnChangeLeaderboardDown = (ImageButton) leaderBoardDialog.findViewById(R.id.imgBtnChangeLeaderBoardDown);
        final ImageButton btnChangeLeaderboardUp = (ImageButton) leaderBoardDialog.findViewById(R.id.imgBtnChangeLeaderBoardUp);
        final TextView tvLeaderboardName = (TextView) leaderBoardDialog.findViewById(R.id.tvLeaderBoardName);
        gameModeLeaderboard = 1;

        btnChangeLeaderboardDown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleSound.start();
                if (gameModeLeaderboard == 1) {
                    gameModeLeaderboard = 4;
                } else {
                    gameModeLeaderboard--;
                }
                switch (gameModeLeaderboard) {
                    case 1:
                        tvLeaderboardName.setText("Normal Beginner");
                        myAdapter.setNickNamesAndScores(nickNamesNB, highScoreBegNorm, curUserPlaceNB);
                        recyclerView.setAdapter(myAdapter);
                        break;
                    case 2:
                        tvLeaderboardName.setText("Normal Advanced");
                        myAdapter.setNickNamesAndScores(nickNamesNA, highScoreAdNorm, curUserPlaceNA);
                        recyclerView.setAdapter(myAdapter);
                        break;
                    case 3:
                        tvLeaderboardName.setText("Endless Beginner");
                        myAdapter.setNickNamesAndScores(nickNamesEB, highScoreBegEnd, curUserPlaceEB);
                        recyclerView.setAdapter(myAdapter);
                        break;
                    case 4:
                        tvLeaderboardName.setText("Endless Advanced");
                        myAdapter.setNickNamesAndScores(nickNamesEA, highScoreAdEnd, curUserPlaceEA);
                        recyclerView.setAdapter(myAdapter);
                        break;
                }
            }
        });

        btnChangeLeaderboardUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleSound.start();
                if (gameModeLeaderboard == 4) {
                    gameModeLeaderboard = 1;
                } else {
                    gameModeLeaderboard++;
                }
                switch (gameModeLeaderboard) {
                    case 1:
                        tvLeaderboardName.setText("Normal Beginner");
                        myAdapter.setNickNamesAndScores(nickNamesNB, highScoreBegNorm, curUserPlaceNB);
                        recyclerView.setAdapter(myAdapter);
                        break;
                    case 2:
                        tvLeaderboardName.setText("Normal Advanced");
                        myAdapter.setNickNamesAndScores(nickNamesNA, highScoreAdNorm, curUserPlaceNA);
                        recyclerView.setAdapter(myAdapter);
                        break;
                    case 3:
                        tvLeaderboardName.setText("Endless Beginner");
                        myAdapter.setNickNamesAndScores(nickNamesEB, highScoreBegEnd, curUserPlaceEB);
                        recyclerView.setAdapter(myAdapter);
                        break;
                    case 4:
                        tvLeaderboardName.setText("Endless Advanced");
                        myAdapter.setNickNamesAndScores(nickNamesEA, highScoreAdEnd, curUserPlaceEA);
                        recyclerView.setAdapter(myAdapter);
                        break;
                }
            }
        });
        leaderBoardDialog.show();
    }



    public void showSettingsDialog(View v) {
        settingsDialog.setContentView(R.layout.dialog_settings);
        settingsDialog.getWindow().setBackgroundDrawableResource(R.drawable.rounddialog);

        final TextView txtClose;
        final SeekBar volControl;
        final AudioManager audioManager;
        final CheckBox checkBoxPoppingWords;
        final Button btnTutorial;
        final Button btnLogOut;

        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        int maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        int curVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);

        volControl = (SeekBar) settingsDialog.findViewById(R.id.volControl);
        txtClose = (TextView) settingsDialog.findViewById(R.id.txtClose);
        checkBoxPoppingWords = (CheckBox) settingsDialog.findViewById(R.id.checkBoxPoppingWords);
        btnTutorial = (Button) settingsDialog.findViewById(R.id.btnTutorial);
        btnLogOut = settingsDialog.findViewById(R.id.btnLogOut);



        volControl.setMax(maxVolume);
        volControl.setProgress(curVolume);

        volControl.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onStopTrackingTouch(SeekBar arg0) {
            }

            @Override
            public void onStartTrackingTouch(SeekBar arg0) {
            }

            @Override
            public void onProgressChanged(SeekBar seekbar, int progress, boolean fromUser) {
                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, progress, 0);
            }
        });

        checkBoxPoppingWords.setChecked(poppingWordsOn);

        checkBoxPoppingWords.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkBoxPoppingWords.isChecked()) {
                    poppingWordsOn = true;
                } else {
                    poppingWordsOn = false;
                }
            }
        });

        txtClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                settingsDialog.dismiss();
            }
        });
        if(auth.getCurrentUser().getEmail().equals("admin@gmail.com"))//so it wont crash because admin doesn't have any db info
        {
            btnTutorial.setEnabled(false);
        }
        btnTutorial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent;
                intent = new Intent(MainActivity.this, GameActivity.class);
                intent.putExtra(EXTRA_IS_TUTORIAL, true);
                startActivity(intent);
                finish();//so cant move back
            }
        });

        btnLogOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                auth.signOut();
                Intent intent = new Intent(MainActivity.this, LogIn.class);
                startActivity(intent);
                finish();
            }
        });

        settingsDialog.show();
    }

    public void moveToGameActivity() {
        Intent intent;
        if (gameMode == 4) {
            intent = new Intent(this, BuildLevel.class);
            startActivity(intent);
            finish();
        } else {
            if (gameMode == 3) //if chosen game mode is multiplayer
            {
                intent = new Intent(this, GameActivity.class);//needs to be to multiplayer activity
            } else {
                intent = new Intent(this, GameActivity.class);
            }
        }


        intent.putExtra(EXTRA_LEVEL_DIFF, levelDiff);
        intent.putExtra(EXTRA_POPPING_WORDS_ON, poppingWordsOn);
        intent.putExtra(EXTRA_GAME_MODE, gameMode);
        intent.putExtra(EXTRA_IS_TUTORIAL, false);
        startActivity(intent);
        finish();//so cant move back
    }
}