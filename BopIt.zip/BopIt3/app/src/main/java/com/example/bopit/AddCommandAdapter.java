package com.example.bopit;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class AddCommandAdapter extends RecyclerView.Adapter<AddCommandAdapter.myViewHolder> {

    Context context;
    int[] commandImages;
    String[] commandNames;
    OnCommandClickListener mOnCommandClickListener;

    public AddCommandAdapter(Context context, int[] commandImages, String[] commandNames, OnCommandClickListener onCommandClickListener)
    {
        this.context=context;
        this.commandNames=commandNames;
        this.commandImages=commandImages;
        this.mOnCommandClickListener=onCommandClickListener;
    }

    @NonNull
    @Override
    public myViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.add_command_row,parent,false);
        return new myViewHolder(view,mOnCommandClickListener);
    }

    @Override
    public void onBindViewHolder(@NonNull myViewHolder holder, int position) {
        holder.tvCommandName.setText((commandNames[position]));
        holder.imgViewCommandLogo.setImageResource(commandImages[position]);
    }

    @Override
    public int getItemCount() {
        return commandImages.length;
    }

    public class myViewHolder extends RecyclerView.ViewHolder {

        TextView tvCommandName;
        ImageView imgViewCommandLogo;
        OnCommandClickListener onCommandClickListener;

        public myViewHolder(@NonNull View itemView, OnCommandClickListener onCommandClickListener) {
            super(itemView);
            tvCommandName=itemView.findViewById(R.id.tvCommandName);
            imgViewCommandLogo=itemView.findViewById(R.id.imgViewCommandLogo);
            this.onCommandClickListener=onCommandClickListener;

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onCommandClickListener.OnCommandClickListener(getAdapterPosition());
                }
            });

        }

    }

    public interface OnCommandClickListener{
        void OnCommandClickListener(int position);
    }
}
