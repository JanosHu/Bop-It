package com.example.bopit;
import static com.example.bopit.CustomGame.hasOrderedCustom;
import static com.example.bopit.CustomGame.isCustomGame;
import static com.example.bopit.CustomGame.orderTypeCustom;
import static com.example.bopit.CustomGame.tvOrderCustom;
import static com.example.bopit.GameActivity.dialogCounter;
import static com.example.bopit.GameActivity.hasOrdered;
import static com.example.bopit.GameActivity.isTutorial;
import static com.example.bopit.GameActivity.tvInstructionsStatic;
import static com.example.bopit.GameActivity.tvOrder;
import static com.example.bopit.GameActivity.orderType;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;
import android.os.IBinder;



public class FlipService extends Service implements SensorEventListener {

    private SensorManager mSensorManager;
    private Sensor mGyroScope;
    private boolean isFirstTut;



    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        mGyroScope = mSensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        mSensorManager.registerListener(this, mGyroScope, SensorManager.SENSOR_DELAY_UI, new Handler());
        isFirstTut=true;
        return START_STICKY;
    }




    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {

        if(Math.abs(sensorEvent.values[1])>12)
        {
            if(isCustomGame)
            {
                orderTypeCustom=OrderType.FLIP;
                tvOrderCustom.setText("Flipped");
                hasOrderedCustom=true;
            }
            else{
                if(isTutorial)
                {
                    if(isFirstTut)
                    {
                        dialogCounter++;
                        tvInstructionsStatic.setText("Good Job! Lets try another order, slice.\n do a slice motion with your phone.");//(maybe have illustration?)
                        isFirstTut=false;
                    }

                }
                else {
                    orderType=OrderType.FLIP;

                }
                hasOrdered=true;
                tvOrder.setText("Flipped");
            }



        }
    }
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }
}
