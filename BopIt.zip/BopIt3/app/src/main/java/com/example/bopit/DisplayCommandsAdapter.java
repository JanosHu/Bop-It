package com.example.bopit;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


public class DisplayCommandsAdapter extends RecyclerView.Adapter<DisplayCommandsAdapter.MyViewHolder>{

    Context context;
    OrderType[] orderTypes;
    int[] images;

    public DisplayCommandsAdapter(OrderType[] orderTypes,int[] images,Context context)
    {
        this.orderTypes=orderTypes;
        this.images=images;
        this.context=context;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.display_commands_row,parent,false);
        return new DisplayCommandsAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.tvBuildCommandName.setText(orderTypes[position]+"");
        holder.imgViewBuildCommandLogo.setImageResource(images[orderTypes[position].ordinal()]);
    }

    @Override
    public int getItemCount() {
        return orderTypes.length;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{

        TextView tvBuildCommandName;
        ImageView imgViewBuildCommandLogo;


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            tvBuildCommandName= itemView.findViewById(R.id.tvBuildCommandName);
            imgViewBuildCommandLogo= itemView.findViewById(R.id.imgViewBuildCommandLogo);
        }
    }
}
