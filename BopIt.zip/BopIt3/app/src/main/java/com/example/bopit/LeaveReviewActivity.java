package com.example.bopit;

import static com.example.bopit.Register.KEY_USER_HAS_REVIEWS;
import static com.example.bopit.Register.KEY_USER_REVIEWS_AMOUNT;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LeaveReviewActivity extends AppCompatActivity {

    public static final String KEY_REVIEW="KEY_REVIEW";


    EditText etReview;
    Button btnSend;
    Button btnBack;

    FirebaseAuth auth;
    FirebaseFirestore db;

    boolean hasReviews;

    Map<String,Object> Rev;
    int reviewAmount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leave_review);

        btnBack=findViewById(R.id.btnSendReviewBack);
        btnSend=findViewById(R.id.btnSendReview);
        etReview=findViewById(R.id.etReview);

        auth = FirebaseAuth.getInstance();
        db =FirebaseFirestore.getInstance();


        String userId = auth.getCurrentUser().getUid();

        hasReviews=false;
        DocumentReference doc = db.collection("Users").document(userId);
        doc.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot value, @Nullable FirebaseFirestoreException error) {
                hasReviews = Boolean.parseBoolean(value.get(KEY_USER_HAS_REVIEWS).toString());//in order to number each review of each user the amount of their reviews is retrieved
            }
        });


            DocumentReference documentReference = db.collection("Reviews").document(userId);
            documentReference.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
                @Override
                public void onEvent(@Nullable DocumentSnapshot value, @Nullable FirebaseFirestoreException error) {
                    reviewAmount = Integer.parseInt(value.get(KEY_USER_REVIEWS_AMOUNT).toString());//in order to number each review of each user the amount of their reviews is retrieved
                }
            });






        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LeaveReviewActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });
        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendReview();
            }
        });
    }

    private void sendReview() {

        String review = etReview.getText().toString();


        DocumentReference documentReference = db.collection("Reviews").document(auth.getCurrentUser().getUid());
        Rev = new HashMap<>();
        Rev.put(KEY_USER_REVIEWS_AMOUNT, reviewAmount + 1);


        documentReference.update(Rev);//add one to the amount of user reviews




        DocumentReference documentReferenceTemp2 = db.collection("Reviews").document(auth.getCurrentUser().getUid()).collection("Reviews").document((reviewAmount + 1) + ".");
        Rev = new HashMap<>();
        Rev.put(KEY_REVIEW + "_" + (reviewAmount + 1), review);


        documentReferenceTemp2.set(Rev);//add the review to the users collection of reviews
;

        Toast.makeText(LeaveReviewActivity.this, "Thank you for leaving your feedback!", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(LeaveReviewActivity.this, MainActivity.class);
        startActivity(intent);
        finish();

    }



}
