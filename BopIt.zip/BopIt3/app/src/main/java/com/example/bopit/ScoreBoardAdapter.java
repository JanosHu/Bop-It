package com.example.bopit;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

public class ScoreBoardAdapter extends RecyclerView.Adapter<ScoreBoardAdapter.MyViewHolder> {

    private Context context;
    private String[] nickNames;
    private int[] highestScores;
    private int curUserPlace;// to highlight the current user in leaderboard



    public ScoreBoardAdapter(Context context, String[] nickNames, int[] highestScores, int curUserPlace)
    {
        this.context=context;
        this.nickNames=nickNames;
        this.highestScores=highestScores;
        this.curUserPlace=curUserPlace;
    }

    public void setNickNamesAndScores(String[] nickNames, int[] highestScores,int curUserPlace)
    {
        this.highestScores=highestScores;
        this.nickNames=nickNames;
        this.curUserPlace=curUserPlace;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.leaderboard_row,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.tvNickName.setText(nickNames[position]+"");
        holder.tvHighScore.setText(highestScores[position]+"");
        holder.leaderBoardPlacement.setText((position+1)+".");
        if(position==curUserPlace-1)
        {
            holder.row.setBackgroundColor(Color.parseColor("#F29F9B"));
        }
    }

    @Override
    public int getItemCount() {
        return nickNames.length;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{

        TextView tvNickName;
        TextView tvHighScore;
        TextView leaderBoardPlacement;
        ConstraintLayout row;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            tvNickName = itemView.findViewById(R.id.tvLeaderboardNickName);
            tvHighScore = itemView.findViewById(R.id.tvLeaderBoardScore);
            leaderBoardPlacement = itemView.findViewById(R.id.tvLeaderboardPlace);
            row= itemView.findViewById(R.id.leaderboardRow);
        }
    }
}
