package com.example.bopit;

import static com.example.bopit.CustomGame.isCustomGame;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import nl.dionsegijn.konfetti.core.Party;
import nl.dionsegijn.konfetti.core.PartyFactory;
import nl.dionsegijn.konfetti.core.emitter.Emitter;
import nl.dionsegijn.konfetti.core.emitter.EmitterConfig;
import nl.dionsegijn.konfetti.core.models.Shape;
import nl.dionsegijn.konfetti.core.models.Size;
import nl.dionsegijn.konfetti.xml.KonfettiView;

public class GameActivity extends AppCompatActivity {

    public static TextView tvOrder;
    public static boolean isTutorial;//to know if to start game or tutorial (static for flip and slice)
    public static int dialogCounter;//for tutorial instructions
    public static boolean hasOrdered;
    public static OrderType orderType;
    public static boolean hasWon;// if correctly did every order
    static TextView tvInstructionsStatic;
    static ConstraintLayout swipingLayoutTutorial;
    public boolean isFirst;//in order to make orders sound once
    FirebaseFirestore db;
    FirebaseAuth auth;
    String userId;
    int beginnerNormalHighScore;//to check if current high score is higher than score
    int advancedNormalHighScore;//and to have it ready
    int beginnerEndlessHighScore;
    int advancedEndlessHighScore;
    String email;
    String nickName;
    TextView tvTimer;
    TextView tvScore;
    ImageButton bopItButton;
    OrderType[] orderArray;
    int levelDiff;
    int gameMode;//1->normal 2->endless 3->multiplayer?
    int score;
    boolean isHighScore;
    long millisUntilFinishedForPause;
    boolean poppingWordsOn;
    String[] fadingPraisesArray;
    int praiseArrayCounter;
    int tutorialSwipeAmount;//to let player swipe more than once
    Intent flipIntent;
    Intent sliceIntent;
    SwipeListner swipeListener, swipeListenerTutorial;
    ConstraintLayout swipeLayout;//the place where swipes are registered
    int orderCounter;//counts current order for order array
    boolean hasFinishedGame;//in order to make game stop receiving actions once it has finished
    MediaPlayer[] orderAudios;//for all order sounds
    private TextView fadingTextView1;//for praises
    private TextView fadingTextView2;
    private TextView tvRandomPraise;
    private Shape.DrawableShape drawableShape = null;//for konfetti

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        final Drawable drawable = ContextCompat.getDrawable(getApplicationContext(), R.drawable.heart);
        drawableShape = new Shape.DrawableShape(drawable, true);

        tvOrder = findViewById(R.id.tvOrder);
        tvTimer = findViewById(R.id.tvTimer);
        tvScore = findViewById(R.id.tvScore);
        bopItButton = findViewById(R.id.bopItButton);

        fadingTextView1 = findViewById(R.id.tvPoppingWords1);
        fadingTextView2 = findViewById(R.id.tvPoppingWords2);


        Intent intent = getIntent();

        gameMode = intent.getIntExtra(MainActivity.EXTRA_GAME_MODE, 1);
        isTutorial = intent.getBooleanExtra(MainActivity.EXTRA_IS_TUTORIAL, false);


        dialogCounter = 0;//for tutorial instructions
        tutorialSwipeAmount = 0;
        levelDiff = intent.getIntExtra(MainActivity.EXTRA_LEVEL_DIFF, 1);
        score = 0;
        isHighScore = false;

        millisUntilFinishedForPause = 0;

        orderAudios = new MediaPlayer[7];
        orderAudios = SetAudios(orderAudios);
        isFirst = true;
        isCustomGame = false;
        hasOrdered = false;
        hasWon = false;


        orderArray = BuildOrderArray(11, levelDiff);//amount of orders and what orders will be in the array
        orderCounter = 0;

        poppingWordsOn = intent.getBooleanExtra(MainActivity.EXTRA_POPPING_WORDS_ON, true);
        fadingPraisesArray = new String[4];
        fadingPraisesArray[0] = "Good Job!";
        fadingPraisesArray[1] = "Nice!";
        fadingPraisesArray[2] = "You Rock!";
        fadingPraisesArray[3] = "Well Done!";
        praiseArrayCounter = -1;

        swipeLayout = findViewById(R.id.SwipeLayout);


        db = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();
        userId = auth.getCurrentUser().getUid();
        DocumentReference documentReference = db.collection("Users").document(userId);
        documentReference.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot value, @Nullable FirebaseFirestoreException error) {
                beginnerNormalHighScore = Integer.parseInt(value.get(Register.KEY_BEGINNER_NORMAL_HIGH_SCORE).toString());
                advancedNormalHighScore = Integer.parseInt(value.get(Register.KEY_ADVANCED_NORMAL_HIGH_SCORE).toString());
                beginnerEndlessHighScore = Integer.parseInt(value.get(Register.KEY_BEGINNER_ENDLESS_HIGH_SCORE).toString());
                advancedEndlessHighScore = Integer.parseInt(value.get(Register.KEY_ADVANCED_ENDLESS_HIGH_SCORE).toString());
                email = value.get(Register.KEY_EMAIL).toString();
                nickName = value.get(Register.KEY_NICKNAME).toString();
            }
        });


        bopItButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                hasOrdered = true;
                orderType = OrderType.PRESS;
                tvOrder.setText("Pressed");
            }
        });

        if (isTutorial) {
            flipIntent = new Intent(this, FlipService.class);
            sliceIntent = new Intent(this, SliceService.class);
            startService(flipIntent);
            startService(sliceIntent);


            displayTutorialDialog();

        } else {

            switch (levelDiff) {//handles which services to activate according to difficulty
                case 1:
                    flipIntent = new Intent(this, FlipService.class);
                    startService(flipIntent);
                    swipeListener = new SwipeListner(swipeLayout);
                    break;
                case 2:
                    flipIntent = new Intent(this, FlipService.class);
                    sliceIntent = new Intent(this, SliceService.class);
                    startService(flipIntent);
                    startService(sliceIntent);
                    swipeListener = new SwipeListner(swipeLayout);
                    break;
                default:
                    break;
            }

            new CountDownTimer(5000, 1000) {
                public void onTick(long millisUntilFinished) {


                    if (!hasFinishedGame) {//as long as game hasn't finished continue to run
                        tvTimer.setText("seconds remaining: " + millisUntilFinished / 1000);

                        if (isFirst)//so audio wont repeat itself
                        {
                            switch (orderArray[orderCounter]) {//order audio handler
                                case PRESS:
                                    orderAudios[0].start();
                                    break;
                                case FLIP:
                                    orderAudios[1].start();
                                    break;
                                case SWIPEUP:
                                    orderAudios[2].start();
                                    break;
                                case SWIPERIGHT:
                                    orderAudios[3].start();
                                    break;
                                case SWIPEDOWN:
                                    orderAudios[4].start();
                                    break;
                                case SWIPELEFT:
                                    orderAudios[5].start();
                                    break;
                                case SLICE:
                                    orderAudios[6].start();
                                    break;
                                default:
                                    break;
                            }
                            isFirst = false;
                        }


                        if (hasOrdered) {
                            if (orderArray[orderCounter] == orderType)//if order that has been received is equal to the required
                            {
                                if (poppingWordsOn)//if player chose to have fading/popping words on through settings on main page
                                {
                                    chooseRandomPraiseText();//have one of two TextViews display a praise
                                }

                                orderCounter++;
                                score++;
                                tvScore.setText("Score: " + score);
                                if (orderCounter == orderArray.length - 1)//if is last order
                                {
                                    if (gameMode == 2)//if game mode is endless-> build new array of orders
                                    {
                                        orderArray = BuildOrderArray(11, levelDiff);//amount of orders and what orders will be in the array
                                        orderCounter = 0;
                                    } else {
                                        hasWon = true;
                                        hasFinishedGame = true;
                                        onFinish();
                                    }

                                }

                                if (!hasWon)//if didn't win yet
                                {
                                    isFirst = true;//is first time for playing vocal order
                                    hasOrdered = false;//hasn't ordered yet
                                    start();
                                }
                            } else {//if order that has been received isn't equal to required order-> end game
                                hasFinishedGame = true;
                                onFinish();
                            }
                        }
                    }
                }

                public void onFinish() {

                    if (gameMode == 1 && levelDiff == 1)//Normal beginner || needs to be changed so score will be time -> normal mode
                    {
                        if (score > beginnerNormalHighScore) {
                            isHighScore = true;
                            DocumentReference documentReference = db.collection("Users").document(userId);
                            Map<String, Object> user = new HashMap<>();
                            user.put(Register.KEY_EMAIL, email);//so it wont erase
                            user.put(Register.KEY_NICKNAME, nickName);//so it wont erase
                            user.put(Register.KEY_BEGINNER_NORMAL_HIGH_SCORE, score);//change to high score ---------------> score needs to be changed to time
                            user.put(Register.KEY_ADVANCED_NORMAL_HIGH_SCORE, advancedNormalHighScore);//so it wont erase
                            user.put(Register.KEY_BEGINNER_ENDLESS_HIGH_SCORE, beginnerEndlessHighScore);//so it wont erase
                            user.put(Register.KEY_ADVANCED_ENDLESS_HIGH_SCORE, advancedEndlessHighScore);//so it wont erase
                            documentReference.set(user).addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void unused) {
                                    Toast.makeText(GameActivity.this, "High score (Beg,Norm) registered", Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                    }
                    if (gameMode == 1 && levelDiff == 2)//Normal advanced || needs to be changed so score will be time -> normal mode
                    {
                        if (score > advancedNormalHighScore) {
                            isHighScore = true;
                            DocumentReference documentReference = db.collection("Users").document(userId);
                            Map<String, Object> user = new HashMap<>();
                            user.put(Register.KEY_EMAIL, email);//so it wont erase
                            user.put(Register.KEY_NICKNAME, nickName);//so it wont erase
                            user.put(Register.KEY_BEGINNER_NORMAL_HIGH_SCORE, beginnerNormalHighScore);//change to high score
                            user.put(Register.KEY_ADVANCED_NORMAL_HIGH_SCORE, score);//change to high score ---------------> score needs to be changed to time
                            user.put(Register.KEY_BEGINNER_ENDLESS_HIGH_SCORE, beginnerEndlessHighScore);//so it wont erase
                            user.put(Register.KEY_ADVANCED_ENDLESS_HIGH_SCORE, advancedEndlessHighScore);//so it wont erase
                            documentReference.set(user).addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void unused) {
                                    Toast.makeText(GameActivity.this, "High score (Beg,Ad) registered", Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                    }
                    if (gameMode == 2 && levelDiff == 1) {//Endless beginner
                        if (score > beginnerEndlessHighScore) {
                            isHighScore = true;
                            DocumentReference documentReference = db.collection("Users").document(userId);
                            Map<String, Object> user = new HashMap<>();
                            user.put(Register.KEY_EMAIL, email);//so it wont erase
                            user.put(Register.KEY_NICKNAME, nickName);//so it wont erase
                            user.put(Register.KEY_BEGINNER_NORMAL_HIGH_SCORE, beginnerNormalHighScore);//so it wont erase
                            user.put(Register.KEY_ADVANCED_NORMAL_HIGH_SCORE, advancedNormalHighScore);//so it wont erase
                            user.put(Register.KEY_BEGINNER_ENDLESS_HIGH_SCORE, score);//change to high score
                            user.put(Register.KEY_ADVANCED_ENDLESS_HIGH_SCORE, advancedEndlessHighScore);//so it wont erase
                            documentReference.set(user).addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void unused) {
                                    Toast.makeText(GameActivity.this, "High score (End,Norm) registered", Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                    }
                    if (gameMode == 2 && levelDiff == 2) {//Endless advanced
                        if (score > advancedEndlessHighScore) {
                            isHighScore = true;
                            DocumentReference documentReference = db.collection("Users").document(userId);
                            Map<String, Object> user = new HashMap<>();
                            user.put(Register.KEY_EMAIL, email);//so it wont erase
                            user.put(Register.KEY_NICKNAME, nickName);//so it wont erase
                            user.put(Register.KEY_BEGINNER_NORMAL_HIGH_SCORE, beginnerNormalHighScore);//so it wont erase
                            user.put(Register.KEY_ADVANCED_NORMAL_HIGH_SCORE, advancedNormalHighScore);//so it wont erase
                            user.put(Register.KEY_BEGINNER_ENDLESS_HIGH_SCORE, beginnerEndlessHighScore);//so it wont erase
                            user.put(Register.KEY_ADVANCED_ENDLESS_HIGH_SCORE, score);//change to high score
                            documentReference.set(user).addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void unused) {
                                    Toast.makeText(GameActivity.this, "High score (End,Ad) registered", Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                    }

                    gameOver();
                    if (hasWon) {
                        tvTimer.setText("Won!");
                    } else {
                        tvTimer.setText("Failed!");
                    }
                    cancel();
                }
            }.start();

            if (hasFinishedGame) {
                stopServices();
            }
        }


    }

    public void displayTutorialDialog() {
        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.dialog_tutorial);

        dialog.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        dialog.show();

        ConstraintLayout constraintLayout = dialog.findViewById(R.id.SwipeLayoutTutorial);//swiping area for tutorial
        swipingLayoutTutorial = constraintLayout;
        View view0 = dialog.findViewById(R.id.view0);//focuses on all the screen
        ImageView imgView1 = dialog.findViewById(R.id.imgView1);//focuses on the timer
        ImageView imgView2 = dialog.findViewById(R.id.imgView2);//focuses on the score
        ImageButton bopItBtnTut = dialog.findViewById(R.id.bopItButtonTutorial);

        TextView tvInstructions = dialog.findViewById(R.id.txt_view);
        tvInstructionsStatic = tvInstructions;

        tvInstructions.setText("Welcome to Bop-IT!");//instructions

        bopItBtnTut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialogCounter++;//continue tutorial instructions
                tvOrder.setText("Pressed");
                bopItBtnTut.setVisibility(View.INVISIBLE);//make button disappear
                tvInstructions.setText("Nice! Now lets try the next order, flip.\n try to flip your phone around.");//(maybe have illustration?)
            }
        });


        view0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                switch (dialogCounter) {
                    case 0:
                        tvInstructions.setText("Here is where we will play.");
                        dialogCounter++;
                        return;
                    case 1:
                        tvInstructions.setText("Lets go over everything!");
                        dialogCounter++;
                        return;
                    case 2:
                        tvInstructions.setText("Bop-It is a simple game.");
                        dialogCounter++;
                        return;
                    case 3:
                        tvInstructions.setText("Bop-It will say orders, you just need to do as it says.");
                        dialogCounter++;
                        return;
                    case 4:
                        tvInstructions.setText("There are a few types of orders, so lets go over them!");
                        dialogCounter++;
                        return;
                    case 5:
                        tvInstructions.setText("The first order is press, try it out!");
                        bopItBtnTut.setVisibility(View.VISIBLE);//make bop it button pressable.
                        return;
                    //6 is added through bopit button
                    //7 is added through flip service
                    //8 is added through slice service
                    case 8:
                        tvInstructions.setText("Swipe has 4 different directions: Up, Down, Left and Right.");
                        dialogCounter++;
                        return;
                    case 9:
                        constraintLayout.setVisibility(View.VISIBLE);//make swiping area visible
                        tvInstructions.setText("This is the swiping area. Try it out!");
                        ConstraintLayout.LayoutParams params = new ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.MATCH_PARENT, ConstraintLayout.LayoutParams.MATCH_PARENT);
                        params.setMargins(0, 0, 0, 800);
                        tvInstructions.setLayoutParams(params); // moves text higher so it wont block the swiping area
                        swipeListenerTutorial = new SwipeListner(swipingLayoutTutorial);
                        dialogCounter++;
                        return;

                    case 10://10 should be added through swipe listener
                        dialogCounter++;
                        tvInstructionsStatic.setText("Now that you are proficient lets go over the rest.");
                        ConstraintLayout.LayoutParams params1 = new ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.MATCH_PARENT, ConstraintLayout.LayoutParams.MATCH_PARENT);
                        params1.setMargins(0, 0, 0, -500);
                        tvInstructions.setLayoutParams(params1); // moves text higher so it wont block the swiping area
                        swipingLayoutTutorial.setVisibility(View.INVISIBLE);
                        return;

                    case 11:
                        imgView1.setVisibility(View.VISIBLE);
                        tvInstructions.setText("Here is Where you will find the time you have left to execute the order.");
                        dialogCounter++;
                        return;
                    case 12:
                        imgView1.setVisibility(View.INVISIBLE);
                        imgView2.setVisibility(View.VISIBLE);
                        tvInstructions.setText("Here is where you will find your score");
                        dialogCounter++;
                        return;
                    case 13:
                        tvInstructions.setText("That's all for now.");
                        dialogCounter++;
                        return;
                    case 14:
                        imgView2.setVisibility(View.INVISIBLE);
                        tvInstructions.setText("Now lets play!");
                        dialogCounter++;
                        return;
                    case 15:
                        Intent intent = new Intent(GameActivity.this, MainActivity.class);
                        startActivity(intent);
                        finish();
                        return;

                }
            }
        });


    }


    public void stopServices() {
        stopService(sliceIntent);
        stopService(flipIntent);
    }


    public MediaPlayer[] SetAudios(MediaPlayer[] orderAudios) {
        orderAudios[0] = MediaPlayer.create(this, R.raw.press);
        orderAudios[1] = MediaPlayer.create(this, R.raw.flip);
        orderAudios[2] = MediaPlayer.create(this, R.raw.swipeup);
        orderAudios[3] = MediaPlayer.create(this, R.raw.swiperight);
        orderAudios[4] = MediaPlayer.create(this, R.raw.swipedown);
        orderAudios[5] = MediaPlayer.create(this, R.raw.swipeleft);
        orderAudios[6] = MediaPlayer.create(this, R.raw.slice);
        return orderAudios;
    }


    public OrderType[] BuildOrderArray(int arrLength, int levelDiff)//builds order array with random orders according to difficulty
    {
        OrderType[] orderArray = new OrderType[arrLength];
        Random random = new Random();
        int lastOrder = 50;//so it wont be equal to any order
        boolean beenDouble = false;// if same order was twice it cant be a third time
        if (levelDiff == 1) {
            for (int i = 0; i < arrLength; i++) {
                int temp = random.nextInt(3);
                if (beenDouble)//if order was twice in a row
                {
                    while (temp == lastOrder)//while current order is equal to last 2
                    {
                        temp = random.nextInt(3);//pick a new order
                    }
                    beenDouble = false;
                }
                if (temp == lastOrder) {
                    beenDouble = true;
                }
                if (temp == 2)//in order to not make most orders swipe(direction) only if random is equal to 2 the order will be swipe(direction)
                {
                    temp = random.nextInt(4) + 2;
                }
                orderArray[i] = OrderType.fromInteger(temp);
                lastOrder = temp;
            }
        } else {
            for (int i = 0; i < arrLength; i++) {
                int temp = random.nextInt(4);
                if (temp == 2)//in order to not make most orders swipe(direction) only if random is equal to 2 the order will be swipe(direction)
                {
                    temp = random.nextInt(4) + 2;
                } else {
                    if (temp == 3)//if equal to three make the order slice
                    {
                        temp = 6;
                    }
                }
                if (beenDouble)//if order was twice in a row
                {
                    while (temp == lastOrder)//while current order is equal to last 2
                    {
                        temp = random.nextInt(4);//pick a new order

                        if (temp == 2)//in order to not make most orders swipe(direction) only if random is equal to 2 the order will be swipe(direction)
                        {
                            temp = random.nextInt(4) + 2;
                        } else {
                            if (temp == 3)//if equal to three make the order slice
                            {
                                temp = 6;
                            }
                        }
                    }
                    beenDouble = false;
                }
                if (temp == lastOrder) {
                    beenDouble = true;
                }
                orderArray[i] = OrderType.fromInteger(temp);
                lastOrder = temp;
            }
        }
        return orderArray;
    }



    public void gameOver() {
        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.dialog_game_over);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));


        dialog.setCancelable(false);

        final TextView tvWonOrLost;
        final Button btnHome;
        final Button btnPlayAgain;
        final TextView tvScoreGameOver;
        final KonfettiView konfettiView;


        tvWonOrLost = dialog.findViewById(R.id.tvWonOrLost);
        btnHome = dialog.findViewById(R.id.btnHome);
        btnPlayAgain = dialog.findViewById(R.id.btnPlayAgain);
        tvScoreGameOver = dialog.findViewById(R.id.tvScoreGameOver);
        konfettiView = dialog.findViewById(R.id.konfettiView);


        btnHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //after game over go back home
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);

            }
        });
        btnPlayAgain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //after game over play again
                Intent intent = new Intent(getApplicationContext(), GameActivity.class);
                intent.putExtra(MainActivity.EXTRA_GAME_MODE, gameMode);//so when playing again it will play the same game mode
                intent.putExtra(MainActivity.EXTRA_LEVEL_DIFF, levelDiff);//so when playing again it will play the same level difficulty
                startActivity(intent);
                finish();//so cant move back
            }
        });

        if (isHighScore) {
            tvWonOrLost.setText("NEW HIGH SCORE: " + score);
            tvScoreGameOver.setText("Awesome!");

            EmitterConfig emitterConfig = new Emitter(5L, TimeUnit.SECONDS).perSecond(50);//building confetti
            Party party = new PartyFactory(emitterConfig)
                    .angle(270)
                    .spread(90)
                    .setSpeedBetween(1f, 5f)
                    .timeToLive(2000L)
                    .shapes(new Shape.Rectangle(0.2f), drawableShape)
                    .sizes(new Size(12, 5f, 0.2f))
                    .position(0.0, 0.0, 1.0, 0.0)
                    .build();

            konfettiView.start(party);//displaying confetti


        } else {
            if (hasWon) {
                tvWonOrLost.setText("You Won!");
            } else {
                tvWonOrLost.setText("You Lost!");
            }
            tvScoreGameOver.setText("Your score was " + score);

        }


        dialog.show();

    }


    public void chooseRandomPraiseText() {
        Random rnd = new Random();
        int temp = rnd.nextInt(2);
        if (temp == 0) {
            tvRandomPraise = fadingTextView1;
        } else {
            tvRandomPraise = fadingTextView2;
        }
        if (praiseArrayCounter + 1 == fadingPraisesArray.length) {
            praiseArrayCounter = 0;
        } else {
            praiseArrayCounter++;
        }
        tvRandomPraise.setText(fadingPraisesArray[praiseArrayCounter]);

        Runnable endRunnable = new Runnable() {
            @Override
            public void run() {
                tvRandomPraise.setText("");
                tvRandomPraise.animate().alpha(1).setDuration(0).setStartDelay(0);//returns the word's alpha (fade level) back to normal
                tvRandomPraise.animate().scaleX(1);//scales word back to normal
                tvRandomPraise.animate().scaleY(1);//scales word back to normal
            }
        };

        tvRandomPraise.animate().alpha(1).setDuration(500).setStartDelay(0);//fades the word in
        tvRandomPraise.animate().scaleX(2);//scales word x
        tvRandomPraise.animate().scaleY(2);//scales word y
        tvRandomPraise.animate().alpha(0).setDuration(500).setStartDelay(500).withEndAction(endRunnable);//fades the word out and calls endRunnable once finished
    }


    private class SwipeListner implements View.OnTouchListener {

        GestureDetector gestureDetector;

        SwipeListner(View view)//constructor
        {
            int threshold = 100;
            int velocityThreshold = 100;

            GestureDetector.SimpleOnGestureListener listener =
                    new GestureDetector.SimpleOnGestureListener() {
                        @Override
                        public boolean onDown(MotionEvent e) {
                            return true;
                        }

                        @Override
                        public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
                            float xDiff = e2.getX() - e1.getX();
                            float yDiff = e2.getY() - e1.getY();
                            try {
                                if (Math.abs(xDiff) > Math.abs(yDiff)) {//x greater than y
                                    if (Math.abs(xDiff) > threshold && Math.abs(velocityX) > velocityThreshold) {
                                        if (xDiff > 0) {
                                            //swiped right
                                            if (isTutorial)//if it is a tutorial
                                            {
                                                if (tutorialSwipeAmount == 5) {
                                                    dialogCounter++;
                                                    tvInstructionsStatic.setText("Now that you are proficient lets go over the rest.");
                                                    swipingLayoutTutorial.setVisibility(View.INVISIBLE);
                                                } else {
                                                    tutorialSwipeAmount++;
                                                }
                                            }

                                            orderType = OrderType.SWIPERIGHT;
                                            tvOrder.setText("Swiped Right");

                                        } else {
                                            //swiped left
                                            if (isTutorial)//if it is a tutorial
                                            {
                                                if (tutorialSwipeAmount == 5) {
                                                    dialogCounter++;
                                                    tvInstructionsStatic.setText("Now that you are proficient lets go over the rest.");
                                                    swipingLayoutTutorial.setVisibility(View.INVISIBLE);
                                                } else {
                                                    tutorialSwipeAmount++;
                                                }
                                            }

                                            orderType = OrderType.SWIPELEFT;
                                            tvOrder.setText("Swiped Left");
                                        }
                                        hasOrdered = true;


                                        return true;
                                    }
                                } else {//y greater than x
                                    if (Math.abs(yDiff) > threshold && Math.abs(velocityY) > velocityThreshold) {
                                        if (yDiff > 0) {
                                            //swiped down
                                            if (isTutorial)//if it is a tutorial
                                            {
                                                if (tutorialSwipeAmount == 5) {
                                                    dialogCounter++;
                                                    tvInstructionsStatic.setText("Now that you are proficient lets go over the rest.");
                                                    swipingLayoutTutorial.setVisibility(View.INVISIBLE);
                                                } else {
                                                    tutorialSwipeAmount++;
                                                }
                                            }
                                            orderType = OrderType.SWIPEDOWN;
                                            tvOrder.setText("Swiped Down");

                                        } else {
                                            //swiped up
                                            if (isTutorial)//if it is a tutorial
                                            {
                                                if (tutorialSwipeAmount == 5) {
                                                    dialogCounter++;
                                                    tvInstructionsStatic.setText("Now that you are proficient lets go over the rest.");
                                                    swipingLayoutTutorial.setVisibility(View.INVISIBLE);
                                                } else {
                                                    tutorialSwipeAmount++;
                                                }
                                            }
                                            orderType = OrderType.SWIPEUP;
                                            tvOrder.setText("Swiped Up");
                                        }
                                        hasOrdered = true;


                                        return true;
                                    }
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            return false;
                        }
                    };
            gestureDetector = new GestureDetector(listener);
            view.setOnTouchListener(this);
        }

        @Override
        public boolean onTouch(View view, MotionEvent motionEvent) {
            return gestureDetector.onTouchEvent(motionEvent);
        }
    }
}